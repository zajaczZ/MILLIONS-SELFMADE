﻿using EasyNetQ.Topology;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MessageBox = System.Windows.Forms.MessageBox;

namespace Legyen_ön_is_milliomos
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void A(object sender, RoutedEventArgs e)
        {
            


            /*Első kérdés*/
            if (kerdes.Text== "Ki nyerte a tavalyi választásokat?")
            {
                gomb1.Background = Brushes.Green;
                egy.Fill = Brushes.Green;
                nyer1.Background = Brushes.Gold;
                
                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                
                
                

                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Melyik a legnépszerűbb párt?";
                gomb1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                egy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "MSZP";
                gomb2.Content = "Fidesz";
                gomb3.Content = "Momentum";
                gomb4.Content = "MKKP";
                lehet.Visibility = Visibility.Visible;


              
            }
            /* 2.kérdés*/
            else if (kerdes.Text == "Melyik a legnépszerűbb párt?")
            {
                egy.Fill = Brushes.Red;
                gomb1.Background = Brushes.Red;
                gomb2.Background = Brushes.Green;
                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*3.kérdés*/
            else if (kerdes.Text== "Kicsoda a Mini Feri?")
            {
                egy.Fill = Brushes.Red;
                gomb1.Background = Brushes.Red;
                gomb2.Background = Brushes.Green;
                ketto.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*4.kérdés*/
            else if (kerdes.Text == "Kitől hangzott el az Őszödi beszéd?")
            {
                gomb3.Background = Brushes.Green;
                gomb1.Background = Brushes.Red;
                egy.Fill = Brushes.Red;
                harom.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*5.kérdés*/
            else if (kerdes.Text== "Ki kapott Kossuth-díjat?")
            {
                gomb3.Background = Brushes.Green;
                gomb1.Background = Brushes.Red;
                egy.Fill = Brushes.Red;
                harom.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*6.kérdés*/
            else if (kerdes.Text == "Hova megyünk?")
            {
                egy.Fill = Brushes.Red;
                gomb1.Background = Brushes.Red;
                gomb4.Background = Brushes.Green;
                negy.Fill = Brushes.Green;

                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*7.kérdés*/
            else if (kerdes.Text == "Hol van dugó állandóan?")
            {
                egy.Fill = Brushes.Red;
                gomb1.Background = Brushes.Red;
                gomb4.Background = Brushes.Green;
                negy.Fill = Brushes.Green;

                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*8.kérdés*/
            else if (kerdes.Text == "Ki a nemzet anyja?")
            {
                gomb1.Background = Brushes.Green;
                nyer8.Background = Brushes.Gold;
                egy.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Melyik évben született Orbán Viktor?";
                gomb1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                egy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "1963";
                gomb2.Content = "1962";
                gomb3.Content = "1961";
                gomb4.Content = "1956";

            }
            /*9.kérdés*/
            else if (kerdes.Text == "Melyik évben született Orbán Viktor?")
            {
                gomb1.Background = Brushes.Green;
                nyer9.Background = Brushes.Gold;
                egy.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Hova küldené MZP a betegeket?";
                gomb1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                egy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "Indiába";
                gomb2.Content = "Kórházba";
                gomb3.Content = "Kukába";
                gomb4.Content = "Frontra";

            }
            /*10.kérdés*/
            else if (kerdes.Text == "Hova küldené MZP a betegeket?")
            {
                gomb1.Background = Brushes.Green;
                nyer10.Background = Brushes.Gold;
                egy.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Melyik az MSZMP utódpártja?";
                gomb1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                egy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "MSZP";
                gomb2.Content = "Fidesz";
                gomb3.Content = "KDNP";
                gomb4.Content = "Mi Hazánk";

            }
            /*11.kérdés*/
            else if (kerdes.Text == "Melyik az MSZMP utódpártja?")
            {
                gomb1.Background = Brushes.Green;
                nyer11.Background = Brushes.Gold;
                egy.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Hogy hívják Orbán Viktor feleségét?";
                gomb1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                egy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "Novák Katalin";
                gomb2.Content = "Lévai Ildikó";
                gomb3.Content = "Lévai Anna";
                gomb4.Content = "Lévai Anikó";

            }
            /*12.kérdés*/
            else if (kerdes.Text == "Hogy hívják Orbán Viktor feleségét?")
            {
                gomb4.Background = Brushes.Green;
                gomb1.Background = Brushes.Red;
                egy.Fill = Brushes.Red;
                negy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }

        }

        private async void B(object sender, RoutedEventArgs e)
        {


            /*Első kérdés*/
            if (kerdes.Text == "Ki nyerte a tavalyi választásokat?")
            {
                ketto.Fill= Brushes.Red;
                gomb1.Background = Brushes.Green;
                gomb2.Background = Brushes.Red;
                egy.Fill= Brushes.Green;

                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }

            /* 2.kérdés*/
            else if (kerdes.Text == "Melyik a legnépszerűbb párt?")
            {
                gomb2.Background = Brushes.Green;
                nyer2.Background = Brushes.Gold;
                ketto.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Kicsoda a Mini Feri?";
                gomb2.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                ketto.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "Jakab Péter";
                gomb2.Content = "MZP";
                gomb3.Content = "Karácsony Gergely";
                gomb4.Content = "Dobrev Klára";

            }
            /*3.kérdés*/
            else if (kerdes.Text == "Kicsoda a Mini Feri?")
            {
                gomb2.Background = Brushes.Green;
                nyer3.Background = Brushes.Gold;
                ketto.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;

                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Kitől hangzott el az Őszödi beszéd?";
                gomb2.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                ketto.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "Vona Gábor";
                gomb2.Content = "Soros György";
                gomb3.Content = "Gyurcsány Ferenc";
                gomb4.Content = "MZP";


            }
            /*4.kérdés*/
            else if (kerdes.Text== "Kitől hangzott el az Őszödi beszéd?")
            {
                gomb3.Background = Brushes.Green;
                harom.Fill = Brushes.Green;
                ketto.Fill = Brushes.Red;
                gomb2.Background = Brushes.Red;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*5.kérdés*/
            else if (kerdes.Text == "Ki kapott Kossuth-díjat?")
            {
                gomb3.Background = Brushes.Green;
                gomb2.Background = Brushes.Red;
                ketto.Fill = Brushes.Red;
                harom.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*6.kérdés*/
            else if (kerdes.Text == "Hova megyünk?")
            {
                ketto.Fill = Brushes.Red;
                gomb2.Background = Brushes.Red;
                gomb4.Background = Brushes.Green;
                negy.Fill = Brushes.Green;

                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*7.kérdés*/
            else if (kerdes.Text == "Hol van dugó állandóan?")
            {
                ketto.Fill = Brushes.Red;
                gomb2.Background = Brushes.Red;
                gomb4.Background = Brushes.Green;
                negy.Fill = Brushes.Green;

                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*8.kérdés*/
            else if (kerdes.Text == "Ki a nemzet anyja?")
            {
                ketto.Fill = Brushes.Red;
                gomb1.Background = Brushes.Green;
                gomb2.Background = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*9.kérdés*/
            else if (kerdes.Text == "Melyik évben született Orbán Viktor?")
            {
                gomb1.Background = Brushes.Green;
                gomb2.Background = Brushes.Red;
                ketto.Fill = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*10.kérdés*/
            else if (kerdes.Text == "Hova küldené MZP a betegeket?")
            {
                gomb1.Background = Brushes.Green;
                gomb2.Background = Brushes.Red;
                ketto.Fill = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*11.kérdés*/
            else if (kerdes.Text == "Melyik az MSZMP utódpártja?")
            {
                gomb1.Background = Brushes.Green;
                gomb2.Background = Brushes.Red;
                ketto.Fill = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*11.kérdés*/
            else if (kerdes.Text == "Melyik az MSZMP utódpártja?")
            {
                gomb1.Background = Brushes.Green;
                nyer11.Background = Brushes.Gold;
                egy.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Hogy hívják Orbán Viktor feleségét?";
                gomb1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                egy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "Novák Katalin";
                gomb2.Content = "Lévai Anikó";
                gomb3.Content = "Lévai Anna";
                gomb4.Content = "Lévai Ildikó";

            }
            /*12.kérdés*/
            else if (kerdes.Text == "Hogy hívják Orbán Viktor feleségét?")
            {
                gomb4.Background = Brushes.Green;
                gomb2.Background = Brushes.Red;
                ketto.Fill = Brushes.Red;
                negy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }

        }

    private async void C(object sender, RoutedEventArgs e)
    {

            /*Első kérdés*/
            if (kerdes.Text == "Ki nyerte a tavalyi választásokat?")
        {
            harom.Fill = Brushes.Red;
            gomb1.Background= Brushes.Green;
            gomb3.Background = Brushes.Red;
            egy.Fill= Brushes.Green;

            nyer1.Background = Brushes.Red;
            nyer2.Background = Brushes.Red;
            nyer3.Background = Brushes.Red;
            nyer4.Background = Brushes.Red;
            nyer5.Background = Brushes.Red;
            nyer6.Background = Brushes.Red;
            nyer7.Background = Brushes.Red;
            nyer8.Background = Brushes.Red;
            nyer9.Background = Brushes.Red;
            nyer10.Background = Brushes.Red;
            nyer11.Background = Brushes.Red;
            nyer12.Background = Brushes.Red;
            MessageBox.Show("Sajnálom ön vesztett");
            gomb1.IsEnabled = false;
            gomb2.IsEnabled = false;
            gomb3.IsEnabled = false;
            gomb4.IsEnabled = false;
            await Task.Delay(500);
            uj.Background = Brushes.Gold;


        }
            /* 2.kérdés*/
            else if (kerdes.Text == "Melyik a legnépszerűbb párt?")
        {
            gomb2.Background = Brushes.Green;
            gomb3.Background = Brushes.Red;
             harom.Fill = Brushes.Red;



            nyer1.Background = Brushes.Red;
            nyer2.Background = Brushes.Red;
            nyer3.Background = Brushes.Red;
            nyer4.Background = Brushes.Red;
            nyer5.Background = Brushes.Red;
            nyer6.Background = Brushes.Red;
            nyer7.Background = Brushes.Red;
            nyer8.Background = Brushes.Red;
            nyer9.Background = Brushes.Red;
            nyer10.Background = Brushes.Red;
            nyer11.Background = Brushes.Red;
            nyer12.Background = Brushes.Red;
            MessageBox.Show("Sajnálom ön vesztett");
            lehet.Visibility = Visibility.Collapsed;
            gomb1.IsEnabled = false;
            gomb2.IsEnabled = false;
            gomb3.IsEnabled = false;
            gomb4.IsEnabled = false;
            await Task.Delay(500);
            uj.Background = Brushes.Gold;

        }
            /*3.kérdés*/
            else if (kerdes.Text == "Kicsoda a Mini Feri?")
            {
                harom.Fill = Brushes.Red;
                gomb3.Background = Brushes.Red;
                gomb2.Background = Brushes.Green;
                ketto.Fill= Brushes.Green;
                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /* 4.kérdés*/
            else if (kerdes.Text == "Kitől hangzott el az Őszödi beszéd?")
            {
                gomb3.Background = Brushes.Green;
                nyer4.Background = Brushes.Gold;
                harom.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Ki kapott Kossuth-díjat?";
                gomb3.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                harom.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "Fluor Tomi";
                gomb2.Content = "Noár";
                gomb3.Content = "Nagy Feró";
                gomb4.Content = "Krúbi";

            }
            /*5.kérdés*/
            else if (kerdes.Text == "Ki kapott Kossuth-díjat?")
            {
                gomb3.Background = Brushes.Green;
                nyer5.Background = Brushes.Gold;
                harom.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Hova megyünk?";
                gomb3.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                harom.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "Balra";
                gomb2.Content = "Lefelé";
                gomb3.Content = "Hátra";
                gomb4.Content = "Előre!";

            }
            /*6.kérdés*/
            else if (kerdes.Text== "Hova megyünk?")
            {
                harom.Fill = Brushes.Red;
                gomb3.Background = Brushes.Red;
                gomb4.Background = Brushes.Green;
                negy.Fill=Brushes.Green;

                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*7.kérdés*/
            else if (kerdes.Text == "Hol van dugó állandóan?")
            {
                harom.Fill = Brushes.Red;
                gomb3.Background = Brushes.Red;
                gomb4.Background = Brushes.Green;
                negy.Fill = Brushes.Green;

                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*8.kérdés*/
            else if (kerdes.Text == "Ki a nemzet anyja?")
            {
                harom.Fill = Brushes.Red;
                gomb1.Background = Brushes.Green;
                gomb3.Background = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*9.kérdés*/
            else if (kerdes.Text == "Melyik évben született Orbán Viktor?")
            {
                gomb1.Background = Brushes.Green;
                gomb3.Background = Brushes.Red;
                ketto.Fill = Brushes.Red;
                harom.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*10.kérdés*/
            else if (kerdes.Text == "Hova küldené MZP a betegeket?")
            {
                gomb1.Background = Brushes.Green;
                gomb3.Background = Brushes.Red;
                harom.Fill = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*11.kérdés*/
            else if (kerdes.Text == "Melyik az MSZMP utódpártja?")
            {
                gomb1.Background = Brushes.Green;
                gomb3.Background = Brushes.Red;
                harom.Fill = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*12.kérdés*/
            else if (kerdes.Text == "Hogy hívják Orbán Viktor feleségét?")
            {
                gomb4.Background = Brushes.Green;
                gomb3.Background = Brushes.Red;
                harom.Fill = Brushes.Red;
                negy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }




        }

        private async void D(object sender, RoutedEventArgs e)
        {

            /*Első kérdés*/
            if (kerdes.Text == "Ki nyerte a tavalyi választásokat?")
            {
                negy.Fill = Brushes.Red;
                gomb1.Background = Brushes.Green;
                gomb4.Background = Brushes.Red;
                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;
                


            }
            /* 2.kérdés*/
            else if (kerdes.Text == "Melyik a legnépszerűbb párt?")
            {
                negy.Fill = Brushes.Red;
                gomb2.Background = Brushes.Green;
                gomb4.Background = Brushes.Red;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*3.kérdés*/
            else if (kerdes.Text == "Kicsoda a Mini Feri?")
            {
                negy.Fill = Brushes.Red;
                gomb4.Background = Brushes.Red;
                negy.Fill = Brushes.Red;
                gomb2.Background = Brushes.Green;
                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*4.kérdés*/
            else if (kerdes.Text == "Kitől hangzott el az Őszödi beszéd?")
            {
                gomb3.Background = Brushes.Green;
                harom.Fill = Brushes.Green;
                gomb4.Background = Brushes.Red;
                negy.Fill = Brushes.Red;

                


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*5.kérdés*/
            else if (kerdes.Text == "Ki kapott Kossuth-díjat?")
            {
                gomb3.Background = Brushes.Green;
                gomb4.Background = Brushes.Red;
                negy.Fill = Brushes.Red;
                harom.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*6.kérdés*/
            else if (kerdes.Text== "Hova megyünk?")
            {
                gomb4.Background = Brushes.Green;
                nyer6.Background = Brushes.Gold;
                negy.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Hol van dugó állandóan?";
                gomb4.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                negy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "Debrecen";
                gomb2.Content = "Győr";
                gomb3.Content = "Szombathely";
                gomb4.Content = "Budapest";

            }
            /*7.kérdés*/
            else if (kerdes.Text == "Hol van dugó állandóan?")
            {
                gomb4.Background = Brushes.Green;
                nyer7.Background = Brushes.Gold;
                negy.Fill = Brushes.Green;

                await Task.Delay(1000);
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;


                await Task.Delay(900);
                gomb1.IsEnabled = true;
                gomb2.IsEnabled = true;
                gomb3.IsEnabled = true;
                gomb4.IsEnabled = true;
                kerdes.Text = "Ki a nemzet anyja?";
                gomb4.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                negy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
                gomb1.Content = "Tóth Gabi";
                gomb2.Content = "Dobrev Klára";
                gomb3.Content = "Donáth Anna";
                gomb4.Content = "Pottyondi Edina";

            }
            /*8.kérdés*/
            else if (kerdes.Text == "Ki a nemzet anyja?")
            {
                negy.Fill = Brushes.Red;
                gomb1.Background = Brushes.Green;
                gomb4.Background = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;

            }
            /*9.kérdés*/
            else if (kerdes.Text == "Melyik évben született Orbán Viktor?")
            {
                gomb1.Background = Brushes.Green;
                gomb4.Background = Brushes.Red;
                ketto.Fill = Brushes.Red;
                negy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*10.kérdés*/
            else if (kerdes.Text == "Hova küldené MZP a betegeket?")
            {
                gomb1.Background = Brushes.Green;
                gomb4.Background = Brushes.Red;
                negy.Fill = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*11.kérdés*/
            else if (kerdes.Text == "Melyik az MSZMP utódpártja?")
            {
                gomb1.Background = Brushes.Green;
                gomb4.Background = Brushes.Red;
                negy.Fill = Brushes.Red;
                egy.Fill = Brushes.Green;


                nyer1.Background = Brushes.Red;
                nyer2.Background = Brushes.Red;
                nyer3.Background = Brushes.Red;
                nyer4.Background = Brushes.Red;
                nyer5.Background = Brushes.Red;
                nyer6.Background = Brushes.Red;
                nyer7.Background = Brushes.Red;
                nyer8.Background = Brushes.Red;
                nyer9.Background = Brushes.Red;
                nyer10.Background = Brushes.Red;
                nyer11.Background = Brushes.Red;
                nyer12.Background = Brushes.Red;
                MessageBox.Show("Sajnálom ön vesztett");
                lehet.Visibility = Visibility.Collapsed;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                await Task.Delay(500);
                uj.Background = Brushes.Gold;


            }
            /*12.kérdés*/
            else if (kerdes.Text == "Hogy hívják Orbán Viktor feleségét?")
            {
                gomb4.Background = Brushes.Green;
                nyer12.Background = Brushes.Gold;
                negy.Fill = Brushes.Green;
                lehet.Visibility = Visibility.Collapsed;

                await Task.Delay(1000);
                MessageBox.Show("Gratulálok, öné a főnyeremény!");
                uj.Background = Brushes.Gold;
                gomb1.IsEnabled = false;
                gomb2.IsEnabled = false;
                gomb3.IsEnabled = false;
                gomb4.IsEnabled = false;
                kerdes.Text = "ÖNÉ A FŐNYEREMÉNY!!!!!!";
                gomb1.Content = "";
                gomb2.Content = "";
                gomb3.Content = "";
                gomb4.Content = "";
                nyer1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer2.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer3.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer4.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer5.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer6.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer7.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer8.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer9.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer10.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer11.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342")); 
                nyer12.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));




                for (int i = 0; i < 10; i++)
                {


                    nyer1.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer2.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer3.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer4.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer5.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer6.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer7.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer8.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer9.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer10.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer11.Background = Brushes.Gold;
                    await Task.Delay(10);
                    nyer12.Background = Brushes.Gold;
                    await Task.Delay(100);
                    nyer1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer2.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer3.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer4.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer5.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer6.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer7.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer8.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer9.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer10.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer11.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    nyer12.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
                    await Task.Delay(100);
                }






            }

        }
        private void newgame(object sender, RoutedEventArgs e)
        {

          

            gomb1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            gomb2.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            gomb3.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            gomb4.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer2.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer3.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer4.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer5.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer6.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer7.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer8.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer9.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer10.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer11.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer12.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            kerdes.Text = "Ki nyerte a tavalyi választásokat?";
            uj.Background= (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            gomb1.IsEnabled = true;
            gomb2.IsEnabled = true;
            gomb3.IsEnabled = true;
            gomb4.IsEnabled = true;
            gomb1.Content = "Fidesz";
            gomb2.Content = "Egyesült Ellenzék";
            gomb3.Content = "Mi Hazánk";
            gomb4.Content = "MEMO";
            lehet.Visibility = Visibility.Collapsed;
            egy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
           ketto.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
            harom.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
            negy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));




        }

        private async void nyeremeny(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ön az aktuális nyereményt választotta!");
            gomb1.IsEnabled = false;
            gomb2.IsEnabled = false;
            gomb3.IsEnabled = false;
            gomb4.IsEnabled = false;


            await Task.Delay(1800);
            gomb1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            gomb2.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            gomb3.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            gomb4.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer1.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer2.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer3.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer4.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer5.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer6.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer7.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer8.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer9.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer10.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer11.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            nyer12.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            kerdes.Text = "Ki nyerte a tavalyi választásokat?";
            uj.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF121342"));
            gomb1.IsEnabled = true;
            gomb2.IsEnabled = true;
            gomb3.IsEnabled = true;
            gomb4.IsEnabled = true;

            gomb1.Content = "Fidesz";
            gomb2.Content = "Egyesült Ellenzék";
            gomb3.Content = "Mi Hazánk";
            gomb4.Content = "MEMO";
            lehet.Visibility = Visibility.Collapsed;
            egy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
            ketto.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
            harom.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));
            negy.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF121342"));



        }
    }
}
